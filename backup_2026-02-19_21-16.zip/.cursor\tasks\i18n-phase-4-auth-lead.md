# Task: i18n Phase 4 — Auth & Lead Flow

## Scope
Files:
- Login/Register modals
- Lead capture forms
- Inquiry messages

## Target Strings
1. Login modal strings
2. Register form labels
3. Lead inquiry form
4. Success/error messages

## DoD
- [ ] All auth strings → i18n keys
- [ ] All lead flow strings → i18n keys
- [ ] LanguageContext.tsx updated
- [ ] npm run build passes
- [ ] Commit and PR
