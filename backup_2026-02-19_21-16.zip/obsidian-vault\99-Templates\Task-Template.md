# {{title}}

## Context
{{what triggered this task}}

## Scope
{{what's included and excluded}}

## Implementation
{{technical details}}

## Results
{{outcome}}

## Related
- [[{{link-1}}]]
- [[{{link-2}}]]
